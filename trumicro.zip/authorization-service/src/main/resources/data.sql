insert into user_auth(id, name, password) values (1, 'naima','naima');





insert into customer_auth(id,name,password) values (100011,'yasmeen ','yasmeen');
insert into customer_auth(id,name,password) values (100012,'asifa','asifa');