package com.cognizant.truyum.customerservice.exception;


public class MenuItemNotAvailableException extends RuntimeException{

	public MenuItemNotAvailableException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MenuItemNotAvailableException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
