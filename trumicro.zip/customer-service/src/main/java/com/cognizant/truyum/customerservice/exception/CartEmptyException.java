package com.cognizant.truyum.customerservice.exception;

public class CartEmptyException extends RuntimeException {

	public CartEmptyException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CartEmptyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
