package com.cognizant.truyum.customerservice.exception;

public class MenuItemNotFoundException extends RuntimeException {

	public MenuItemNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MenuItemNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
